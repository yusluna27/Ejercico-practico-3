/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iglesiaevangelica;

/**
 *
 * @author yusme
 */
public class Iglesia {
    String nombre;
    String nombrePastor;
    int cantidadFeligreses;
    Feligres[] feligreses;
    double montoTotalGanancias;
    double impuestoMunicipalidad;
    double impuestoComedor;
    double gananciaPastor;

    public Iglesia(String nombre, String nombrePastor, int cantidadFeligreses) {
        this.nombre             = nombre;
        this.nombrePastor       = nombrePastor;
        this.cantidadFeligreses = cantidadFeligreses;
        this.feligreses         = new Feligres[cantidadFeligreses];
    }

    public void agregarFeligrés(int nPersona, String nombre, String cedula, int diezmo) {
        feligreses[nPersona] = new Feligres(nombre, cedula, diezmo);
        montoTotalGanancias += diezmo;
    }

    public void calcularImpuestos() {
        impuestoMunicipalidad = montoTotalGanancias * 0.09;
        impuestoComedor       = montoTotalGanancias * 0.21;
        gananciaPastor        = montoTotalGanancias * 0.7;
    }

    public void mostrarInforme() {
        System.out.println("Información de la Iglesia:  " + nombre);
        System.out.println("Nombre del Pastor:          " + nombrePastor);
        System.out.println("Cantidad de feligreses:     " + cantidadFeligreses);
        System.out.println("Monto total de ganancias:   " + montoTotalGanancias);
        System.out.println("Ganancia para el pastor:    " + gananciaPastor);
        System.out.println("Impuesto para la municipalidad (infraestructura): " + impuestoMunicipalidad);
        System.out.println("Impuesto para el comedor municipal:               " + impuestoComedor);
        

        System.out.println("Feligreses con diezmo igual a 0:");
        for (Feligres feligrés : feligreses) {
            if (feligrés.diezmo == 0) {
                System.out.println("Nombre: " + feligrés.nombre + ", Cédula: " + feligrés.cedula);
            }
        }

        System.out.println("Feligreses con diezmo mayor a 100000:");
        for (Feligres feligrés : feligreses) {
            if (feligrés.diezmo > 100000) {
                System.out.println("Nombre: " + feligrés.nombre + ", Cédula: " + feligrés.cedula);
            }
        }
    }

   
    static class Feligres {
        private String nombre;
        private String cedula;
        private int    diezmo;

        public Feligres(String nombre, String cedula, int diezmo) {
            this.nombre = nombre;
            this.cedula = cedula;
            this.diezmo = diezmo;
        }
    }
}

    

    

