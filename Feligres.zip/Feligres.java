/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iglesiaevangelica;

/**
 *
 * @author yusme
 */
public class Feligres {
    private String nombre;
    private String cedula;
    private int    diezmo;

    public Feligres(String nombre, String cedula, int diezmo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.diezmo = diezmo;
    }
}

    

