/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package iglesiaevangelica;

/**
 *
 * @author yusme
 */
public class IglesiaEvangelica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Iglesia iglesia = new Iglesia("Iglesia San Francisco", "Juan Cruz", 3);

        iglesia.agregarFeligrés(0, "Chan-Yeol", "12345678", 150000);
        iglesia.agregarFeligrés(1, "Chin-Hwa" , "89101112", 0);
        iglesia.agregarFeligrés(2, "Dong-Sun" , "13141516", 80000);

        iglesia.calcularImpuestos();
        iglesia.mostrarInforme();
    }
}
